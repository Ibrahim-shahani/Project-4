# Project7-Pharma_data_analysis-
Project7-Pharma Data Analysis: Conducted comprehensive analysis of pharmaceutical data to identify market trends, product performance, and sales patterns. Utilized statistical methods to derive actionable insights for strategic decision-making within the industry
